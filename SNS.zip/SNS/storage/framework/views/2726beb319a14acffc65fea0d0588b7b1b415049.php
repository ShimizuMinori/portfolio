<?php $__env->startSection('content'); ?>

<body>

<!-- 投稿フォーム -->
<div id="post">
    <div>
        <img class="userIcon" src="<?php echo e(asset('/images/' . $name->images)); ?>">

        <?php echo Form::open(['url' => 'post/create']); ?>


            <div class="form-group">
                <?php echo Form::input('text', 'newPost', null, ['required', 'class' => 'newPost', 'placeholder' => '何をつぶやこうか...?']); ?>

            </div>

            <button type="submit" class="postBtn">
                <img src="/images/post.png" alt="投稿ボタン">
            </button>

        <?php echo Form::close(); ?>

    </div>
</div>



<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="Box">

    <!-- foreachにて一時的に値を格納している変数からブラウザに表示させたい内容を->"アロー"を使ってカラム名を指定 -->
   <div class="postBox00">

       <div class="postBox01">
           <div class="postBox1">
                <img class="userIcon" src="/images/<?php echo e($list->images); ?>" alt="ユーザーアイコン">
                <p class="postuser"><?php echo e($name->username); ?></p>
                <p class="posttime"><?php echo e($list->created_at); ?></p>
            </div>
            <div class="postBox2">
                <p><?php echo e($list->posts); ?></p>
            </div>
        </div>

        <!-- 削除機能 -->
        <div class="deleteBtn">
            <a  href="/post/<?php echo e($list->id); ?>/delete"onclick="return confirm('こちらの投稿を削除してもよろしいでしょうか？')">
            <img src="<?php echo e(asset('images/trash_h.png')); ?>" alt="削除" ></a>
        </div>

        <!-- 編集機能 -->
        <div class="updeteBtn">
            <!-- モーダルを開くボタン -->
            <a href="" class="modal-open" data-target="modal<?php echo e($list->id); ?>">
            <img src="<?php echo e(asset('images/edit.png')); ?>" alt="編集">
            </a>
        </div>
    </div>

     <!-- 暗転背景 -->
     <div class="overlay"></div>

        <!-- モーダルウィンドウ -->
           <div class="modal-window" id="modal<?php echo e($list->id); ?>">
                <div class="inner">
                    <div class="inner_post">
                        <?php echo Form::open(array('url' => '/post/update', 'method' => 'post')); ?>

                        <?php echo Form::input('hidden','updateid',$list->id); ?>

                        <?php echo Form::input('text','update',$list->posts,['class' => 'input', 'required']); ?>

                    </div>
                    <button type="submit" class="inner-btn"><img src="<?php echo e(asset('images/edit.png')); ?>" alt="編集"></button>
                    <?php echo Form::close(); ?>

                </div>
            </div>


</div>

</body>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/dawnSNS-Laravelのコピー/resources/views/posts/index.blade.php ENDPATH**/ ?>