

<?php $__env->startSection('content'); ?>



<!-- ログイン中のユーザープロフィール 作成途中-->
<!-- <?php if($user->id == Auth::id()): ?>
    <div class=""></div> -->



<!-- 他ユーザープロフィール -->
<!-- <?php elseif($user->id == $id): ?>
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <div class="">
        <img src="/images/<?php echo e($user->images); ?>" alt="ユーザーアイコン"></>
        <p><?php echo e($user->username); ?></p>
        <p><?php echo e($user->created_at); ?></p>
        <p><?php echo e($user->posts); ?></p>
    </div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>


<?php $__env->stopSection(); ?> -->
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/dawnSNS-Laravel/resources/views/users//profile.blade.php ENDPATH**/ ?>