<?php $__env->startSection('content'); ?>

<div class="wrap">

<?php echo Form::open(); ?>


<h2>DAWNSNSへようこそ</h2>

<p>
<?php echo e(Form::label('input','Mail Adress')); ?>

<?php echo e(Form::text('mail',null,['class' => 'input'])); ?>

</p>

<p>
<?php echo e(Form::label('input','password')); ?>

<?php echo e(Form::password('password',['class' => 'input',"type"=>"password"])); ?>

</p>

<?php echo e(Form::submit('ログイン',['class' => 'btn'])); ?>


<p><a  class="link" href="/register">新規ユーザーの方はこちら</a></p>

<?php echo Form::close(); ?>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/dawnSNS-Laravel3/resources/views/auth/login.blade.php ENDPATH**/ ?>