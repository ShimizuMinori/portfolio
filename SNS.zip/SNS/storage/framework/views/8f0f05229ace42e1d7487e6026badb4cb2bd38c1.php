<?php $__env->startSection('content'); ?>

  <!-- 検索窓の設置 -->
  <div id="search">
      <div class="search_form">
        <?php echo Form::open(array('url' => '/searching', 'method' => 'post')); ?>


        <?php echo e(Form::text('search',null,['class' => 'search', 'placeholder' => 'ユーザー名'])); ?>

        <?php echo Form::submit('🔎',['class' => 'search_btn']); ?>

        <?php echo Form::close(); ?>

      </div>

      <!-- 検索ワードの表示 -->
      <div class="search_word">
          <!-- 検索ワードがあった時だけ吐き出す -->
          <!-- issetはnullが偽 -->
          <?php if(isset($search_word)): ?>
              <p>検索ワード：<?php echo e($search_word); ?></p>
          <?php endif; ?>
      </div>
  </div>

  <hr class="separate">


  <!-- 検索結果が出るまではただの一覧表示 -->
  <!-- コントローラー側で処理するから、bladeではresultの表示だけ -->
  <div id="result">
      <?php $__empty_1 = true; $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="result_user">
            <a href="/<?php echo e($result->id); ?>/otherprofile"><img class="bicImg" src="images/<?php echo e($result->images); ?>" alt="プロフィール画像"></a>
            <p class="result_username"><?php echo e($result->username); ?></p>

            <!-- フォローワーがいる時は「はずす」ボタンを表示する -->
            <div class="">
              <?php if(in_array($result->id,$check)): ?>
              <a href="/<?php echo e($result->id); ?>/unFollow"><p class="unfollowBtn">フォローはずす</p></a>

              <!-- フォロワーがいない時は「フォローする」ボタンを表示 -->
              <?php else: ?>
              <a href="/<?php echo e($result->id); ?>/follow"><p class="followBtn">フォローする</p></a>
              <?php endif; ?>
            </div>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>該当なし</p>
      <?php endif; ?>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/dawnSNS-Laravel/resources/views/users/search.blade.php ENDPATH**/ ?>