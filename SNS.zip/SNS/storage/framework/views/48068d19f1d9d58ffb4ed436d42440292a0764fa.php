<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="postBox1">
    <img class="userIcon" src="<?php echo e(asset('storage/'.$test->images)); ?>" alt="ユーザーアイコン">
    <p class="postuser"><?php echo e($test->username); ?></p>
    <p class="posttime"><?php echo e($test->created_at); ?></p>
  </div>
  <div class="postBox2">
    <p><?php echo e($test->posts); ?></p>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/SNS.vol0/resources/views/posts/test.blade.php ENDPATH**/ ?>