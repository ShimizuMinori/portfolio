

<?php $__env->startSection('content'); ?>

<!-- ①フォロワー一覧 -->
<div id="followBox">
    <h1>Follower list</h1>

    <div class="followsImage">
    <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="/<?php echo e($images->id); ?>/otherprofile"><img class="followsIcon" src="<?php echo e(asset('/images/' . $images->images)); ?>" alt="ユーザーアイコン"></a>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>フォロワーはいません。</p>

    <?php endif; ?>
    </div>
</div>


<!-- ②フォロワー投稿一覧 -->
    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="profilePost">
        <div class="postBox">
            <a href="/<?php echo e($list->id); ?>/otherprofile"><img class="userIcon" src="<?php echo e(asset('/images/' . $images->images)); ?>" alt="ユーザーアイコン"></a>
            <p class="postuser"><?php echo e($list->username); ?></p>
            <p class="posttime"><?php echo e($list->created_at); ?></p>
        </div>
        <p class="post"><?php echo e($list->posts); ?></p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/dawnSNS-Laravel/resources/views/follows/followerList.blade.php ENDPATH**/ ?>