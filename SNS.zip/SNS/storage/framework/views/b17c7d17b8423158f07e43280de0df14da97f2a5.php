<?php $__env->startSection('content'); ?>


<div class="added">

    <p class="name"> <?php echo e(session('username')); ?>さん</p>
    <p>ようこそ！DAWNSNSへ！</p>
    <br>


    <p>ユーザー登録が完了しました。<br>
    さっそく、ログインをしてみましょう。</p>



    <p class="btn"><a class="btn_link" href="/login">ログイン画面へ</a></p>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/dawnSNS-Laravel/resources/views/auth/added.blade.php ENDPATH**/ ?>