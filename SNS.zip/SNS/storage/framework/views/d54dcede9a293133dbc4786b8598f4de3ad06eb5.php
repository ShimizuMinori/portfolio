<?php $__env->startSection('content'); ?>

<div class="wrap">

<?php echo Form::open(); ?>


<h2>新規ユーザー登録</h2>

<p>Username<br>

<?php echo e(Form::label('')); ?>

<?php echo e(Form::text('username',null,['class' => 'input',"placeholder"=>"dawn"])); ?>

</p>
<?php if($errors->has('username')): ?>
<p><?php echo e($errors->first('username')); ?></p>
<?php endif; ?>

<p>Mail Adress<br>
<?php echo e(Form::label('')); ?>

<?php echo e(Form::text('mail',null,['class' => 'input',"placeholder"=>"dawn@dawn.jp"])); ?>

</p>
<?php if($errors->has('mail')): ?>
<p><?php echo e($errors->first('mail')); ?></p>
<?php endif; ?>

<p>Password<br>
<?php echo e(Form::label('')); ?>

<?php echo e(Form::password('password',null,['class' => 'input'])); ?>

</p>
<?php if($errors->has('password')): ?>
<p><?php echo e($errors->first('password')); ?></p>
<?php endif; ?>

<p>Password confirm<br>
<?php echo e(Form::label('')); ?>

<?php echo e(Form::password('password_confirmation',null,['class' => 'input',"type"=>"password"])); ?>

</p>
<?php if($errors->has('password_confirmation')): ?>
<p><?php echo e($errors->first('password_confirmation')); ?></p>
<?php endif; ?>
<!-- パスワード確認 -->




<?php echo e(Form::submit('REGISTER',['class' => 'btn'])); ?>


<p><a class="link" href="/login">ログイン画面へ戻る</a></p>

<?php echo Form::close(); ?>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/SNS/resources/views/auth/register.blade.php ENDPATH**/ ?>