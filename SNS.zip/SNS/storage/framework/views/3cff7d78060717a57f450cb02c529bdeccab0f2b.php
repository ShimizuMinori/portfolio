

<?php $__env->startSection('content'); ?>


<!-- 他ユーザープロフィール -->
<div id="otherprofileBox">
        <div class="otherprofile">
            <p><img class="userIcon" src="<?php echo e(asset('/images/' . $user->images)); ?>" alt="ユーザーアイコン"></p>
            <p class="profileName">Name　　<?php echo e($user->username); ?></p>
        </div>

        <p class="bio">Bio　　<?php echo e($user->bio); ?></p>

        <!-- フォローボタン -->
        <div class="">
            <?php if(in_array($user->id,$check)): ?>
                <a href="/<?php echo e($user->id); ?>/unFollow"><p class="profile_unfollowBtn">フォローはずす</p></a>
            <?php else: ?>
                <a href="/<?php echo e($user->id); ?>/follow"><p class="profile_followBtn">フォローする</p></a>
            <?php endif; ?>
        </div>
</div>


<!-- 投稿内容 -->
<?php $__currentLoopData = $user_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div id="profilePost">
        <div class="postBox">
            <p><img class="userIcon" src="<?php echo e(asset('/images/' . $user_post->images)); ?>" alt="ユーザーアイコン"></p>
            <p class="postuser"><?php echo e($user_post->username); ?></p>
            <p class="posttime"><?php echo e($user_post->created_at); ?></p>
        </div>
        <p class="post"><?php echo e($user_post->posts); ?></p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/dawnSNS-Laravel/resources/views/users/otherprofile.blade.php ENDPATH**/ ?>