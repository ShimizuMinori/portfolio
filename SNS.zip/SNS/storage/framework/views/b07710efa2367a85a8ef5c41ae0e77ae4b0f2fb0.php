<?php $__env->startSection('content'); ?>

  <!-- 検索欄 -->
  <div id="search">
      <div class="search_form">
        <?php echo Form::open(array('url' => '/searching', 'method' => 'post')); ?>

        <?php echo e(Form::text('search',null,['class' => 'search', 'placeholder' => 'ユーザー名'])); ?>

        <?php echo Form::submit('🔎',['class' => 'search_btn']); ?>

        <?php echo Form::close(); ?>

      </div>

      <!-- 検索ワードの表示 -->
      <div class="search_word">
          <!-- 検索ワードがあった場合表示 -->
          <!-- isset関数は、変数に値がセットされていて、かつNULLでないときに、TRUEを戻り値として返す。 -->
          <?php if(isset($search_word)): ?>
              <p>検索ワード：<?php echo e($search_word); ?></p>
          <?php endif; ?>
      </div>
  </div>


  <!-- hr：「horizontal rule（水平方向の罫線）」の略、水平の横線を引くためのタグ -->
  <hr>


  <!-- 検ユーザー一覧表示または検索後の画面 -->
  <!-- コントローラー側で処理するから、bladeではresultの表示だけ -->
  <div id="result">
      <?php $__empty_1 = true; $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="result_user">
            <a href="/<?php echo e($result->id); ?>/otherprofile"><img class="bicImg" src="images/<?php echo e($result->images); ?>" alt="プロフィール画像"></a>
            <p class="result_username"><?php echo e($result->username); ?></p>

            <div>
              <!-- フォローワーがいる時は「はずす」ボタンを表示する -->
              <?php if(in_array($result->id,$check)): ?>
              <a href="/<?php echo e($result->id); ?>/unFollow"><p class="unfollowBtn">フォローはずす</p></a>

              <!-- フォロワーがいない時は「フォローする」ボタンを表示 -->
              <?php else: ?>
              <a href="/<?php echo e($result->id); ?>/follow"><p class="followBtn">フォローする</p></a>
              <?php endif; ?>
            </div>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>該当なし</p>
      <?php endif; ?>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/dawnSNS-Laravelのコピー/resources/views/users/search.blade.php ENDPATH**/ ?>