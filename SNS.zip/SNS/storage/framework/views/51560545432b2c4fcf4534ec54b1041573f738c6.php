

<?php $__env->startSection('content'); ?>


<!-- ①ログイン中のユーザープロフィール 作成途中-->
    <div id="profile">

        <div class="profileIcon">
            <img class="userIcon" src="images/<?php echo e($name->images); ?>" alt="ログインユーザーのアイコン">
        </div>

        <?php echo Form::open(['action' => 'UsersController@updateprofile', 'method' => 'post', 'files' => true]); ?>

        <div class="">
            <div class="profileBox">
                <p class="">UserName</p>
                <?php echo e(Form::label('ユーザー名')); ?>

                <?php echo e(Form::input('username','username',$name->username,['class' => 'profileForm',"placeholder"=>"$name->username"])); ?>


                <?php if($errors->has('username')): ?>
                <p><?php echo e($errors->first('username')); ?></p>
                <?php endif; ?>
            </div>

            <div class="profileBox">
                <p class="">MailAddress</p>
                <?php echo e(Form::label('メールアドレス')); ?>

                <?php echo e(Form::input('mail','mail',$name->mail,['class' => 'profileForm',])); ?>


                <?php if($errors->has('mail')): ?>
                <p><?php echo e($errors->first('mail')); ?></p>
                <?php endif; ?>
            </div>


            <div class="profileBox">
                <p class="formTitle">Password</p>
                <?php echo e(Form::label('旧パスワード')); ?>

                <?php echo e(Form::input('password','password',$name->password,['class'=>'profileForm','disabled'])); ?>

            </div>

            <div class="profileBox">
                <p class="formTitle">newPassword</p>
                <?php echo e(Form::label('新パスワード')); ?>

                <?php echo e(Form::input('update_password','update_password',null,['class' => 'profileForm',"type"=>"password"])); ?>


                <?php if($errors->has('update_password')): ?>
                <p><?php echo e($errors->first('update_password')); ?></p>
                <?php endif; ?>
            </div>


            <div class="profileBox">
                <p class="formTitle">Bio</p>
                <?php echo e(Form::label('自己紹介')); ?>

                <?php echo e(Form::input('bio','bio',$name->bio,['class' => 'profileForm',"placeholder"=>"$name->bio"])); ?>


                <?php if($errors->has('bio')): ?>
                <p><?php echo e($errors->first('bio')); ?></p>
                <?php endif; ?>
            </div>


            <div class="profileBox">
                    <p class="formTitle">IconImage</p>
                <div class="profile_icon">
                    <?php echo e(Form::label('アイコン画像')); ?>

                    <?php echo e(Form::file('update_images',null,$name->images,['class' => 'profileIcon',"type"=>"file"])); ?>

                </div>
            </div>
        </div>

    </div>

            <div class="profileBox">
                <button class="updateBtn" type="submit">更新</button>
            </div>
        <?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/dawnSNS-Laravel3/resources/views/users/profile.blade.php ENDPATH**/ ?>